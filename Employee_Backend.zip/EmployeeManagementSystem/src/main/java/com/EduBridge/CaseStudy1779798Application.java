package com.EduBridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaseStudy1779798Application {

	public static void main(String[] args) {
		SpringApplication.run(CaseStudy1779798Application.class, args);
		System.out.println("Hello All");
	}

}
